import React from "react";

export default function Refecto({ data }) {
  const recur = (data) => {
    if (typeof data === "string") {
      try {
        data = JSON.parse(data);
      } catch (e) {
        return data;
      }
    }

    if (typeof data === "object" && data !== null) {
      for (const key in data) {
        data[key] = recur(data[key]);
      }
    }
    return data;
  };

  const formattedData = recur(data);

  return (
    <div className="code-block">
      <pre>{JSON.stringify(formattedData, null, 2)}</pre>
    </div>
  );
}
