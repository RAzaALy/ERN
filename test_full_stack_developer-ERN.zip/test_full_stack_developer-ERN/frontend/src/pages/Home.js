import React from "react";
import axios from "axios";
import Refecto from "../components/Refecto";

export default function Home() {
  const [data, setData] = React.useState(null);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:5000/data");
        setData(response?.data);
        console.log(response.data);
      } catch (err) {
        console.log(err.message);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h1>Hi Developer</h1>
      {data &&
        typeof data === "object" &&
        Object.keys(data).length > 0 &&
        data.map((item, index) => <Refecto key={index} data={item} />)}
    </div>
  );
}
